import java.io.IOException;
import java.util.ArrayList;
import java.util.List;




public class DC {

    public static final int MinPASSWORD_LENGTH = 5;

    Donor donors;
    NGO Ngo;


    public DC(Donor donors, NGO Ngo) {
        this.donors = donors;
        this.Ngo = Ngo;
    }


    public static void ChoiceIllegalArgumentException(int choice){

        if(choice < 1 || choice > 3)
            throw new IllegalArgumentException();

    }

    public static List<DC> matching(List<Donor> donors, List<User> donation, List<User> receiver, List<NGO> ngos)
            throws IOException {

        List<DC> record = new ArrayList<DC>();
        for (int i = 0; i < donation.size(); i++) {
            for (int j = 0; j < receiver.size(); j++) {

                if (donation.get(i).getAids().equals(receiver.get(j).getAids())) {
                    String aids = donation.get(i).getAids();
                    String donorname = donation.get(i).getUserName();
                    String userphone = getPhonefromlist(donorname, donors);
                    String ngoname = receiver.get(j).getUserName();
                    int manpower = getManPowerfromlist(ngoname, ngos);
                    int donated = 0;

                    if (receiver.get(j).getQuantity() == 0)
                        continue;

                    if (donation.get(i).compareTo(receiver.get(j)) == 1) {
                        donated = receiver.get(j).getQuantity();
                        int remain = donation.get(i).getQuantity() - receiver.get(j).getQuantity();
                        donation.set(i, new User(donorname, remain, aids));
                        receiver.set(j, new User(ngoname, 0, aids));
                        record.add(
                                new DC(new Donor(donorname, userphone, donated, aids), new NGO(ngoname, manpower)));

                    } else if (donation.get(i).compareTo(receiver.get(j)) == -1) {
                        donated = donation.get(i).getQuantity();
                        int remain = receiver.get(j).getQuantity() - donation.get(i).getQuantity();
                        donation.set(i, new User(donorname, 0, aids));
                        receiver.set(j, new User(ngoname, remain, aids));

                        record.add(
                                new DC(new Donor(donorname, userphone, donated, aids), new NGO(ngoname, manpower)));

                        break;

                    } else {
                        donated = donation.get(i).getQuantity();
                        donation.set(i, new User(donorname, 0, aids));
                        receiver.set(j, new User(ngoname, 0, aids));

                        record.add(
                                new DC(new Donor(donorname, userphone, donated, aids), new NGO(ngoname, manpower)));
                        break;
                    }

                }
            }
        }
        return record;
    }

    public static String getPhonefromlist(String donorname, List<Donor> donors) {

        String phone = null;
        for (int i = 0; i < donors.size(); i++) {
            if (donors.get(i).getUserName().equals(donorname)) {
                phone = donors.get(i).getPhone();
                break;
            }
        }
        return phone;
    }


    public static int getManPowerfromlist(String ngoname, List<NGO> ngos) {

        int manpower = 0;
        for (int i = 0; i < ngos.size(); i++) {
            if (ngos.get(i).getUserName().equals(ngoname)) {
                manpower = ngos.get(i).getManpower();
                break;
            }
        }
        return manpower;
    }


}

