import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class NGO extends User{
 

    private int manpower;


    NGO(){}

    public NGO(String username, int manpower) {
        super(username);
        this.manpower = manpower;
    }

    public NGO(String username, int quantity, int manpower) {
        super(username, quantity);
        this.manpower = manpower;
    }


    public NGO(String username, int quantity, String aids){
        super(username, quantity, aids);
    }

    public NGO(String role, String username,String password,String aids,int quantity, int manpower){
        super(role,username,password,aids,quantity);
        this.manpower = manpower;
    }


    public void setManpower(int manpower) {
        this.manpower = manpower;
    }

    public int getManpower() {
        return manpower;
    }


    public static List<NGO> readNgoFromFile() throws IOException {
        List<NGO> ngos = new ArrayList<>();

        List<String> lines = Files.readAllLines(Paths.get("NgoList.csv"));
        for (int i = 0; i < lines.size(); i++) {
            String[] items = lines.get(i).split(",");
            // items[0] is username, items[1] is manpower
            int manpower = Integer.parseInt(items[1]);
            ngos.add(new NGO(items[0], manpower));
        }
        return ngos;
    }


    @Override
    public String toString() {
        
        return username +  " " + manpower;
    }

    
    public String toCSVString() {
        return  username + "," + manpower;
    }
    
}