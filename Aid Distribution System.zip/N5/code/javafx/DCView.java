import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DCView extends Application {

    public class Record {
        

        private SimpleStringProperty username, phone, aids, quantity,  user,manpower;

        public String getUserName() {
            return username.get();
        }

        public String getPhone() {
            return phone.get();
        }

        public String getAids() {
            return aids.get();
        }

        public String getQuantity() {
            return quantity.get();
        }

        public String getUser() {
            return user.get();
        }
        
        public String getManpower() {
            return manpower.get();
        }

        Record(String f1, String phone, String f3, int i, String f5, int j) {

            this.user = new SimpleStringProperty(f1);
            this.phone = new SimpleStringProperty(phone);
            this.aids = new SimpleStringProperty(f3);
            this.quantity = new SimpleStringProperty(String.valueOf(i));
            this.username = new SimpleStringProperty(f5);
            this.manpower = new SimpleStringProperty(String.valueOf(j));

        }

    }

    private final TableView<Record> tableView = new TableView<>();

    private final ObservableList<Record> dataList = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("DCview");

        Group root = new Group();

        TableColumn columnF1 = new TableColumn("Donor");
        columnF1.setCellValueFactory(new PropertyValueFactory<>("User"));

        TableColumn columnF2 = new TableColumn("Phone");
        columnF2.setCellValueFactory( new PropertyValueFactory<>("phone"));

        TableColumn columnF3 = new TableColumn("Aids");
        columnF3.setCellValueFactory(new PropertyValueFactory<>("aids"));

        TableColumn columnF4 = new TableColumn("Quantity");
        columnF4.setCellValueFactory( new PropertyValueFactory<>("quantity"));

        TableColumn columnF5 = new TableColumn("NGO");
        columnF5.setCellValueFactory(new PropertyValueFactory<>("UserName"));

        TableColumn columnF6 = new TableColumn("Manpower");
        columnF6.setCellValueFactory(new PropertyValueFactory<>("manpower"));

        tableView.setItems(dataList);
        tableView.getColumns().addAll(columnF1, columnF2, columnF3, columnF4, columnF5, columnF6);

        VBox vBox = new VBox();
        vBox.setSpacing(10);
        vBox.getChildren().add(tableView);

        root.getChildren().add(vBox);

        primaryStage.setScene(new Scene(root, 700, 250));
        primaryStage.show();

        readlist();
    }

    private void readlist() {
        try {
            List<User> donation = User.readDonationFromFile();
            List<User> receiver = User.readReceiverFromFile();
            List<Donor> donors = Donor.readDonorFromFile();
            List<NGO> ngos = NGO.readNgoFromFile();
            List<DC> list = DC.matching(donors, donation, receiver, ngos);

            for (int i = 0; i < list.size(); i++) {
                // String[] items = list.get(i);
                Record record = new Record(list.get(i).donors.getUserName(), list.get(i).donors.getPhone(),
                        list.get(i).donors.getAids(), list.get(i).donors.getQuantity(),
                        list.get(i).Ngo.getUserName(), list.get(i).Ngo.getManpower());
                dataList.add(record);

            }

        } catch (IOException ex) {
            Logger.getLogger(DCView.class.getName())
                    .log(Level.SEVERE, null, ex);
        }

    }

    public static void main(String[] args) {
        launch(args);
    }

}