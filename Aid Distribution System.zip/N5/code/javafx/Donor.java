import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;


public class Donor extends User {
    private String phone;

   
    public Donor() {
    }

    
    public Donor(String username, String phone) {
        super(username);
        this.phone = phone;
    }

    
    public Donor(String username, int quantity, String phone) {
        super(username, quantity);
        this.phone = phone;
    }

  
    public Donor(String username, String phone, int quantity, String aids) {
        super(username, quantity, aids);
        this.phone = phone;
    }

   
    public String getPhone() {
        return phone;
    }

   
    public static List<Donor> readDonorFromFile() throws IOException {
        List<Donor> donors = new ArrayList<>();

        List<String> lines = Files.readAllLines(Paths.get("DonorList.csv"));
        for (int i = 0; i < lines.size(); i++) {
            String[] items = lines.get(i).split(",");
            // items[0] is username, items[1] is phone
            donors.add(new Donor(items[0], items[1]));
        }
        return donors;
    }

   
    public static void donor(Stage primaryStage, String usernamelogin, List<User> users, List<User> donation,List<Donor> donors)  {

        Button enterbutton = new Button("Enter");
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
        pane.setHgap(5.5);
        pane.setVgap(5.5);

        Label aids = new Label("aids");
        pane.add(aids, 0, 0);
        TextField inputaid = new TextField();
        pane.add(inputaid, 1, 0);

        Label quantity = new Label("quantity");
        pane.add(quantity, 0, 1);
        TextField inputquantity = new TextField();
        pane.add( inputquantity, 1, 1);
        pane.add( enterbutton, 1, 2);

        Label detail = new Label();
        enterbutton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
              int quantity = Integer.parseInt (inputquantity.getText()); 
              donation.add(new User(usernamelogin, quantity,inputaid.getText()));
              try {
                saveToFile(donation, 2);
            } 
                catch (IOException e1) {
                    e1.printStackTrace();
                }
              detail.setText("Successful Input");
              pane.add( detail, 1, 3);
              
            }});

        
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Donor"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
    }

  
    public static void saveDonorToFile(List<Donor> list)  {
        GridPane pane = new GridPane();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++)
            sb.append(list.get(i).toCSVString() + "\n");
            try {
                Files.write(Paths.get("DonorList.csv"), sb.toString().getBytes());
            } catch (IOException e) {
                pane.add(new Label("File existing error"), 0, 3);
            }
    }

   
    public String toString() {
        return username + " " + phone;
    }

    public String toCSVString() {
        return username + "," + phone;
    }
}