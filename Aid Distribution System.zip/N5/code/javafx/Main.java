import java.io.IOException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.application.Application;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Main extends Application {

  public void start(Stage primaryStage) throws IOException {
    // Create a pane and set its properties
    GridPane pane = new GridPane();
    pane.setAlignment(Pos.CENTER);
    pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
    pane.setHgap(5.5);
    pane.setVgap(5.5);

    List<User> users = User.readUserFromFile();
    List<User> donation = User.readDonationFromFile();
    List<Donor> donors = Donor.readDonorFromFile();

    Button donorButton = new Button("Donor");

    pane.add(donorButton, 0, 0);
    // pane.add(ngoButton, 0, 1);
    GridPane.setHalignment(donorButton, HPos.LEFT);


    donorButton.setOnAction(e -> loginregistermenu(primaryStage, "Donor", users, donation, donors));


    // Create a scene and place it in the stage
    Scene scene = new Scene(pane);
    primaryStage.setTitle("MainMenu"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  public void loginregistermenu(Stage primaryStage, String role, List<User> users, List<User> donation,
      List<Donor> donors) {
    // Create a pane and set its properties
    GridPane pane = new GridPane();
    pane.setAlignment(Pos.CENTER);
    pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
    pane.setHgap(5.5);
    pane.setVgap(5.5);

    Button registerButton = new Button("Register");
    Button loginButton = new Button("Login");
    pane.add(registerButton, 0, 0);
    pane.add(loginButton, 0, 1);
    GridPane.setHalignment(registerButton, HPos.LEFT);
    GridPane.setHalignment(loginButton, HPos.LEFT);

    registerButton.setOnAction(e -> {
      try {
        registerpage(primaryStage, role, users, donation, donors);
      } catch (IOException e1) {
        pane.add(new Label("File existing error"), 0, 3);
      }
    });

    loginButton.setOnAction(e -> loginaccount(primaryStage, role, users, donation, donors));

    // Create a scene and place it in the stage
    Scene scene = new Scene(pane);
    primaryStage.setTitle("MainMenu"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  public void registerpage(Stage primaryStage, String role, List<User> users, List<User> donation, List<Donor> donors)
      throws IOException {

    Button Nextbutton = new Button("Next");
    GridPane pane = new GridPane();
    pane.setAlignment(Pos.CENTER);
    pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
    pane.setHgap(5.5);
    pane.setVgap(5.5);

    pane.add(new Label("Username:"), 0, 0);

    TextField userRegisterInput = new TextField();
    pane.add(userRegisterInput, 1, 0);

    pane.add(new Label("Password:"), 0, 1);

    TextField passRegisterInput = new TextField();
    pane.add(passRegisterInput, 1, 1);

    pane.add(new Label("Phone:"), 0, 2);

    TextField PhoneInput = new TextField();
    pane.add(PhoneInput, 1, 2);

    Button registerbutton = new Button("Submit");
    pane.add(registerbutton, 1, 3);

    Label detail = new Label();
    pane.add(detail, 1, 4);

    GridPane.setHalignment(registerbutton, HPos.RIGHT);

    registerbutton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent e){
        users.add(new User(role, userRegisterInput.getText(), passRegisterInput.getText()));
        donors.add(new Donor(userRegisterInput.getText(), PhoneInput.getText()));
        detail.setText("Registration is completed.The registration name is "
            + userRegisterInput.getText() + "Please login with your new account.");
        pane.add(Nextbutton, 1, 5);
        
        try {
          User.saveToFile(users, 1);
        } 
        catch (IOException e1) {
          e1.printStackTrace();
        }
        Donor.saveDonorToFile(donors);
        
      }
    });

    GridPane.setHalignment(Nextbutton, HPos.RIGHT);
    Nextbutton.setOnAction(e -> loginaccount(primaryStage, role, users, donation, donors));
    Scene scene = new Scene(pane);
    primaryStage.setTitle("Register"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

  }

  public void loginaccount(Stage primaryStage, String role, List<User> users, List<User> donation, List<Donor> donors) {
    TextField usernamelogin = new TextField();
    TextField passwordlogin = new TextField();
    Button loginbutton = new Button("Log in");
    Label detail = new Label();
    BooleanProperty login = new SimpleBooleanProperty(false);

    GridPane pane = new GridPane();
    pane.setAlignment(Pos.CENTER);
    pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
    pane.setHgap(5.5);
    pane.setVgap(5.5);

    pane.add(new Label("Username:"), 0, 0);
    pane.add(usernamelogin, 1, 0);
    pane.add(new Label("Password:"), 0, 1);
    pane.add(passwordlogin, 1, 1);
    pane.add(loginbutton, 1, 2);
    pane.add(detail, 1, 3);
    GridPane.setHalignment(loginbutton, HPos.RIGHT);

    Scene scene = new Scene(pane);
    primaryStage.setTitle("Login"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    loginbutton.setOnAction(new EventHandler<ActionEvent>() {
      @Override
      public void handle(ActionEvent e) {
        for (int i = 0; i < users.size(); i++) {
          if (role.equals(users.get(i).getRole())
              && usernamelogin.getText().equals(users.get(i).getUserName())
              && passwordlogin.getText().equals(users.get(i).getPassword())) {

            Button NextButton = new Button("Next");
            detail.setText("Successful login");
            pane.add(NextButton, 1, 5);
            NextButton.setOnAction(new EventHandler<ActionEvent>() {
              public void handle(ActionEvent ex) {
                Donor.donor(primaryStage, usernamelogin.getText(), users, donation, donors);
              }
            });
            login.set(true);
          }
        }
        if (!login.get())
          detail.setText("Login failed. Invalid username or password");

      }
    });
  }
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */

  public static void main(String[] args) {
    launch(args);
  }

}
