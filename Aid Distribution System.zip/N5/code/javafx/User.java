import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class User implements Comparable<User> {

    protected String username;
    protected String password;
    protected String role;
    protected String aids;
    protected int quantity;

    /** 
     * 
     */
    public User(){}

    /** 
     * 
     */
    public User(String role, String username, String password) {
        this.role = role;
        this.username = username;
        this.password = password;
    }

    /** 
     * 
     */
    public User(String username) {
        this.username = username;
    }
    public User(String username , String aids) {
        this.username = username;
        this.aids = aids;
    }

    /** 
     * 
     */
    public User(String username, int quantity) {
        this.username = username;
        this.quantity = quantity;
    }

    /** 
     * 
     */
    public User(String username, int quantity, String aids) {
        this.username = username;
        this.quantity = quantity;
        this.aids = aids;
    }
    
    /** 
     * 
     */
    public User(String role, String username, String password,String aids,int quantity)
    {
        this.role = role;
        this.username = username;
        this.password = password;
        this.aids = aids;
        this.quantity = quantity;
    }



    public void setUsername(String username) {
        this.username = username;
    }
    

    public String getUserName(){
        return username;
    }
    

    public String getPassword(){
        return password;
    }


    public String getAids() {
        return aids;
    }

    

    public int getQuantity() {
        return quantity;
    }


    public String getRole() {
        return role;
    }


    public static List<User> readUserFromFile() throws IOException {
        List<User> users = new ArrayList<User>();

        List<String> lines = Files.readAllLines(Paths.get("User.csv"));
        for (int i = 0; i < lines.size(); i++) {
            String[] items = lines.get(i).split(",");
            // items[0] is role, items[1] is username, items[2] is password
            users.add(new User(items[0], items[1], items[2]));
        }
        return users;
    }


    public static List<User> readDonationFromFile() throws IOException {
        List<User> donation = new ArrayList<User>();

        List<String> lines = Files.readAllLines(Paths.get("Donation.csv"));
        for (int i = 0; i < lines.size(); i++) {
            String[] items = lines.get(i).split(",");
            // items[0] is username, items[1] is quantity, items[2] is aid
            int quantity = Integer.parseInt(items[1]);
            donation.add(new User(items[0], quantity, items[2]));
        }
        return donation;
    }

    
    /** 
     * @return List<User>
     * @throws IOException
     */
    public static List<User> readReceiverFromFile() throws IOException {
        List<User> receiver = new ArrayList<User>();

        List<String> lines = Files.readAllLines(Paths.get("Receiver.csv"));
        for (int i = 0; i < lines.size(); i++) {
            String[] items = lines.get(i).split(",");
            // items[0] is username, items[1] is quantity, items[2] is aid
            int quantity = Integer.parseInt(items[1]);
            receiver.add(new User(items[0], quantity, items[2]));
        }
        return receiver;
    }

    public static void saveToFile(List<User> list, int type) throws IOException{
        StringBuilder sb = new StringBuilder();
        // for (int i = 0; i < list.size(); i++)
        //     sb.append(list.get(i).toCSVString() + "\n");
        if (type == 1) {
            for (int i = 0; i < list.size(); i++)
                sb.append(list.get(i).toCSVString() + "\n");
            Files.write(Paths.get("User.csv"), sb.toString().getBytes());
        }   
        else if (type == 2) {
            for (int i = 0; i < list.size(); i++)
                sb.append(list.get(i).toCSVString1() + "\n");
            Files.write(Paths.get("Donation.csv"), sb.toString().getBytes());
        }     
        else if (type == 3) {
            for (int i = 0; i < list.size(); i++)
                sb.append(list.get(i).toCSVString1() + "\n"); 
            Files.write(Paths.get("Receiver.csv"), sb.toString().getBytes());
        }           
    }

    
    /** 
     * @return String
     */
    public String toString() {
        return role + " " + username + " " + password;
    }

    
    /** 
     * @return String
     */
    public String toCSVString() {
        return role + "," + username + "," + password;    
    }  

    
    /** 
     * @return String
     */
    public String toCSVString1() {
        return username + "," + quantity + "," + aids;
}

    
    /** 
     * @param o
     * @return int
     */
    @Override
    public int compareTo(User o) {
        if(this.quantity>o.quantity)
            return 1;
            else if(this.quantity < o.quantity)
                return -1;
                    else return 0;
    }
    
    /** 
     * @param number
     */
    public static void IllegalArgumentException(int number){
        if (number < 0) 
        throw new IllegalArgumentException("The number must be positive.\n");
    }  
    
    
    /** 
     * @param strNum
     * @return boolean
     */
    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            int d = Integer.parseInt(strNum);
        } 
        catch (NumberFormatException e) {
            return false;
        }
        return true;
    }  
}







