import java.util.List;

/*
 * Viewboard is a interface class which contatins viewlist method
 */
public interface Viewboard {

    public void viewList(List<Project> list);
}